#include "pch.h"
#include "MysteryAlien.h"


MysteryAlien::MysteryAlien(sf::Texture text) : Alien(text) {

}

MysteryAlien::~MysteryAlien() {

}

void MysteryAlien::display() {

}

void MysteryAlien::animation() {

}

void MysteryAlien::eraseAlien() {

}