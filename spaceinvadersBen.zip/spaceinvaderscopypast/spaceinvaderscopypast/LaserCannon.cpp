#include "pch.h"
#include "LaserCannon.h"
#include <string>


LaserCannon::LaserCannon(sf::Texture * text) : Entity(*text) {
	fon.loadFromFile("space_invaders.ttf");
	tex.setFont(fon);
	t.setTexture(*text);
	t.setTextureRect(sf::IntRect(5, 100, 65, 40));
	t.setPosition(50, 580);
	t.scale(0.8, 0.8);
	t1 = t;
	t1.setPosition(50, 650);
	t2 = t;
	t2.setPosition(100, 650);
}

LaserCannon::~LaserCannon() {

}

void LaserCannon::move(bool direc) {
	if (direc&&t.getPosition().x > 0) {
		t.move(-.1, 0);
	}
	if (t.getPosition().x < 535 && !direc) {
		t.move(.1, 0);
	}
}

void LaserCannon::display(sf::RenderWindow & window) {
	tex.setString(std::to_string(lives));
	tex.setPosition(15, 650);

	window.draw(tex);
	if (lives >= 2) {
		window.draw(t1);
	}
	if (lives >= 3) {
		window.draw(t2);
	}
	if (lives > 0) {
		window.draw(t);
	}
}

sf::Vector2f LaserCannon::getCannonPosition() {
	return t.getPosition();
}

void LaserCannon::die() {
	lives--;
}
