#include "pch.h"
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Object.h"
#include "Entity.h"
#include "Alien.h"
#include "MysteryAlien.h"
#include "LaserCannon.h"
#include "Laser.h"
#include "Bunker.h"
#include "Manager.h"

int main()
{
	//The window
	sf::RenderWindow window(sf::VideoMode(600, 700), "SFML works!");

	//Makes a texture pointer
	sf::Texture texture;
	texture.loadFromFile("SpriteSheet.jpg");
	sf::Texture* point = &texture;

	//Make the class objects
	Object obj(texture);
	LaserCannon cannon(point);
	Laser las(point);
	Bunker bunk;

	//Checks if the laser is alive
	bool lasAlive = false;

	//Just a timer kinda thingy for a delay
	int exp = 0;

	//Makes the line at the bottom
	sf::RectangleShape rec(sf::Vector2f(600, 1));
	rec.setPosition(0, 650);
	rec.setFillColor(sf::Color::Green);


	while (window.isOpen())
	{
		//Kills laser if it goes off screen
		if (las.offScreen()) {
			lasAlive = false;
		}

		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();

			//Shoots out laser
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
				if (!lasAlive&&exp<=1) {
					las.setLasPosition(cannon.getCannonPosition());
					lasAlive = true;
				}
			}
			//Kills cannon when key is pressed
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::J)) {
				cannon.die();
				system("pause");
			}

		}

		//Checks if laser collides and moves the laser
		if (lasAlive) {
			if (bunk.collision(las.getLasPosition())) {
				lasAlive = false;
			}
		}
		las.move();

		//Check if explosion is true and after a delay sets explosion to false
		//and kills the laser
		if (bunk.getExplosion()) {
			if (exp > 300) {
				bunk.setExplosion(false);
				lasAlive = false;
				exp = 0;
			}
			exp++;
		}


		//Moves lasercannon
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
			cannon.move(true);
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
			cannon.move(false);
		}


		window.clear();
		//Displays the cannon
		cannon.display(window);
		//Displays the bunkers
		bunk.display(window);
		//Displays the laser
		if (lasAlive) {
			las.display(window);
		}
		//Draws the line at the bottom
		window.draw(rec);
		//Displaus everything
		window.display();
	}

	return 0;
}