#pragma once

#include "Object.h"

class Bunker : public Object
{
public:
	Bunker();
	~Bunker();
	bool collision(sf::Vector2f);
	void display(sf::RenderWindow&);
	bool getExplosion();
	void setExplosion(bool);
private:
	int team = 0;
	int collisions = 0;
	//Needed to check when to draw the explosion vertex array
	bool explos = false;
	std::vector<sf::Vertex> vertices;
	std::vector<sf::Vertex> explosions;
};

