#pragma once

#include "Entity.h"

class Laser : public Entity
{
public:
	Laser();
	Laser(sf::Texture*);
	~Laser();
	void display(sf::RenderWindow &);
	void move();
	bool offScreen();
	void setLasPosition(sf::Vector2f);
	sf::Vector2f getLasPosition();
private:
	int team;
	sf::RectangleShape las;
};

