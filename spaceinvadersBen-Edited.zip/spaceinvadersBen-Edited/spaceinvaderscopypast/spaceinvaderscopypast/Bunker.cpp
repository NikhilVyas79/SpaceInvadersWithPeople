#include "pch.h"
#include "Bunker.h"

Bunker::Bunker() {
	//Makes the bunker
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 20; i++) {
			for (int g = 0; g < 18; g++) {
				if ((i + g < 5) || (i - g > 14) ||
					(i + g > 20 && g > 13 && i < 10) || (i - g <= -3 && g > 13 && i > 8)) {
				}
				else {
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 500.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 503.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 503.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 500.f + 3 * g), sf::Color::Green));
				}
			}
		}
	}

	//Makes the explosion vertex array
	for (int i = 0; i < 9; i++) {
		for (int g = 0; g < 9; g++) {
			explosions.push_back(sf::Vertex(sf::Vector2f(0.f + 3 * i, 3 * g), sf::Color::Transparent));
			explosions.push_back(sf::Vertex(sf::Vector2f(0.f + 3 * i, 3 + 3 * g), sf::Color::Transparent));
			explosions.push_back(sf::Vertex(sf::Vector2f(3.f + 3 * i, 3 + 3 * g), sf::Color::Transparent));
			explosions.push_back(sf::Vertex(sf::Vector2f(3.f + 3 * i, 3 * g), sf::Color::Transparent));
		}
	}

	//This entire section below is shaping the explosion vertex array to look like an explosion
	int checker = 0;
	int absx, absy;

	for (int i = 0; i < 81; i++) {
		for (int i = 0; i < explosions.size() / 4; i++)
		{
			if ((explosions[4 * i].position.y - 10.5 < 5 && explosions[4 * i].position.y - 10.5 > -5) &&
				(explosions[4 * i].position.x - 10.5 < 5 && explosions[4 * i].position.x - 10.5 > -5)) {
				for (int g = 0; g < 4; g++) {
					explosions[4 * i + g].color = sf::Color::Green;
				}
			}
		}
		for (int i = 0; i < explosions.size() / 4; i++)
		{
			absx = (10.5 - explosions[4 * i].position.x) * (10.5 - explosions[4 * i].position.x);
			absy = (10.5 - explosions[4 * i].position.y) * (10.5 - explosions[4 * i].position.y);
			if ((absx + absy < 175)) {
				if (checker%3==0)
				{
					for (int g = 0; g < 4; g++) {
						explosions[4 * i + g].color = sf::Color::Green;
					}
				}
				checker++;
			
			}
		}
	}
}

Bunker::~Bunker() {

}

bool Bunker::collision(sf::Vector2f lasPos) {
	//This part checks for collision between player laser and bunker and destroys the bunker accordingly
	bool checker = false;
	int absx = 0;
	int absy = 0;

	for (int i = 0; i < vertices.size() / 4; i++) {
		
		if ((vertices[4 * i].position.y - lasPos.y < 1 && vertices[4 * i].position.y - lasPos.y > -1) &&
			(vertices[4 * i].position.x - lasPos.x < 2 && vertices[4 * i].position.x - lasPos.x > -2) &&
			vertices[4 * i].color == sf::Color::Green) {
			for (int g = 0; g < 4; g++) {
				vertices[4 * i + g].color = sf::Color::Black;
			}

			explos = true;
			for (int i = 0; i < vertices.size() / 4; i++)
			{
				if ((vertices[4 * i].position.y - lasPos.y < 8 && vertices[4 * i].position.y - lasPos.y > -8) &&
					(vertices[4 * i].position.x - lasPos.x < 4 && vertices[4 * i].position.x - lasPos.x > -4) &&
					vertices[4 * i].color == sf::Color::Green) {
					for (int g = 0; g < 4; g++) {
						vertices[4 * i + g].color = sf::Color::Black;
					}
				}
			}
			for (int i = 0; i < vertices.size() / 4; i++)
			{
				absx = (lasPos.x - vertices[4 * i].position.x)* (lasPos.x - vertices[4 * i].position.x);
				absy = (lasPos.y - vertices[4 * i].position.y) * (lasPos.y - vertices[4 * i].position.y);
				if ((absx + absy < 144 && vertices[4 * i].color == sf::Color::Green)) {
					if (checker)
					{
						for (int g = 0; g < 4; g++) {
							vertices[4 * i + g].color = sf::Color::Black;
						}
						checker = false;
					}
					else
					{
						checker = true;
					}
				}
			}

			//This part moves the explosion vertex array to the site of the collision
			for (int i = 0; i < 9; i++) {
				for (int g = 0; g < 9; g++)
				{
					explosions.at(4 * (i * 9 + g)).position.x = lasPos.x + 3 * i  - 10;
					explosions.at(4 * (i * 9 + g)).position.y = lasPos.y + 3 * g - 13;
					explosions.at((i * 9 + g) * 4 + 1).position.x = lasPos.x + 3 * i - 10;
					explosions.at((i * 9 + g) * 4 + 1).position.y = lasPos.y + 3 + 3 *g  - 13;
					explosions.at((i * 9 + g) * 4 + 2).position.x = lasPos.x + 3 +3 * i - 10;
					explosions.at((i * 9 + g) * 4 + 2).position.y = lasPos.y + 3 + 3 * g - 13;
					explosions.at((i * 9 + g) * 4 + 3).position.x = lasPos.x + 3 + 3 * i - 10;
					explosions.at((i * 9 + g) * 4 + 3).position.y = lasPos.y + 3 * g - 13;
				}
			}
			return true;
		}

	}
	return false;
}

//Displays the bunker and the explosion when needed
void Bunker::display(sf::RenderWindow& window) {
	window.draw(&vertices[0], vertices.size(), sf::Quads);
	if (explos) {
		window.draw(&explosions[0], explosions.size(), sf::Quads);
	}
}

bool Bunker::getExplosion() {
	return explos;
}

void Bunker::setExplosion(bool x) {
	explos = x;
}
