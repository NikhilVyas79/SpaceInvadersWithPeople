#include "pch.h"
#include "Laser.h"


Laser::Laser() : Entity()
{


}

//Makes the laser
Laser::Laser(sf::Texture *text) : Entity(*text) {
	las.setSize(sf::Vector2f(1.5, 15.f));
	las.setPosition(1000.f, 1000.f);
	las.setFillColor(sf::Color::Green);
}

Laser::~Laser() {

}

//Displays the laser and changes its color based on where the laser is at in the screen
void Laser::display(sf::RenderWindow & window) {
	if (las.getPosition().y > 450) {
		las.setFillColor(sf::Color::Green);
	}
	else if (las.getPosition().y > 100) {
		las.setFillColor(sf::Color::White);
	}
	else {
		las.setFillColor(sf::Color::Red);
	}
	window.draw(las);
}

//Moves the laser
void Laser::move() {
	las.move(0, -0.4);
}

//Checks if the laser is off screen
bool Laser::offScreen() {
	if (las.getPosition().y < 0) {
		return true;
	}
	return false;
}

//Sets the laser position
void Laser::setLasPosition(sf::Vector2f x) {
	las.setPosition(x);
	las.move(27, -15);
}

//Gets the laser position
sf::Vector2f Laser::getLasPosition() {
	return las.getPosition();
}
