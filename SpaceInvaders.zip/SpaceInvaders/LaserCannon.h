#pragma once

#include "Entity.h"

class LaserCannon : public Entity
{
public:
	LaserCannon(sf::Texture *);
	~LaserCannon();
	void move(bool);
	void display(sf::RenderWindow &);
	sf::Vector2f getCannonPosition();
	void die();
private:
	int lives=3;
	sf::Sprite t;
	sf::Text tex;
	sf::Font fon;
	sf::Sprite t1;
	sf::Sprite t2;
};

