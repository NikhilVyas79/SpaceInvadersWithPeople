/*
Space Invaders project




contributors: Ethan Doll, Conn0r May
*/

#include <iostream>
#include <SFML/Graphics.hpp>
#include "StateManager.h"

int main()
{
	StateManager control;
	DisplayState test;
	return 0;
}
