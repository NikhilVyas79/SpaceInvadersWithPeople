#include "StateManager.h"


//Sets up the state manager
//Default window size = (600, 800), Default window name = "SFML!"
StateManager::StateManager()
{
}


//Sets up the state manager with a custom name and size 
//
StateManager::StateManager(sf::Vector2f windowSize, std::string windowName)
{
}


//Deletes any dynamic variables or objects
//
StateManager::~StateManager()
{
}


//Starts the state manager used to handle all states.
//Draws and handles events. 
void StateManager::init(DisplayState* d)
{
}


//Adds a state to last position in the vector
//
void StateManager::addState(DisplayState* d)
{
}


//Sets the focused state to the indexed state 
//Returns false if the state does not exist 
bool StateManager::selectState(int index)
{
	return false;
}
