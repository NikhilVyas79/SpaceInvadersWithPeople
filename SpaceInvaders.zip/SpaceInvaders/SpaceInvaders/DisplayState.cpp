#include "DisplayState.h"


//Used to init everything in display state.
//
DisplayState::DisplayState()
{
}


//used to delete any dynamic memory variables and objects
//
DisplayState::~DisplayState()
{
}


//Takes in a SFML event that is collected in the state manager
//
void DisplayState::eventHandle(sf::Event* e)
{
}


//used for key events with out a wait
//
void DisplayState::keyHandle()
{
}


//draw all objects in this function
//
void DisplayState::draw(sf::RenderWindow* target)
{
}


//called before draw
//no time
void DisplayState::update()
{
}


//called after the nextstate and draw
//has a clock to do things based on time
void DisplayState::fixedUpdate(sf::Clock clock)
{
}


//called after draw and before fixedupdate
//check if the state needs to be changed and changes it
int DisplayState::nextState(std::vector<DisplayState*> d)
{
	return 0;
}


//sets the name of the state 
//
void DisplayState::setName(std::string name)
{
}


//Sets the window size for the state to use
//does not set the actual window size
void DisplayState::setWindow(sf::Vector2f w)
{
}


//returns the name of the state
//used to search for states
std::string DisplayState::getName()
{
	return stateName;
}
