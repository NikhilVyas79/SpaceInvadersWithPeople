#ifndef DISPLAYSTATE_H
#define DISPLAYSTATE_H

#include <SFML/Graphics.hpp>

class DisplayState
{
public:
	DisplayState();
	~DisplayState();

	void virtual eventHandle(sf::Event* e);
	void virtual keyHandle();
	void virtual draw(sf::RenderWindow* target);
	void virtual update();
	void virtual fixedUpdate(sf::Clock clock);
	int virtual nextState(std::vector<DisplayState*> d);

	void setName(std::string name);
	void setWindow(sf::Vector2f w);
	std::string getName();

protected:
	std::string stateName;
	sf::Vector2f windowSize;
};

#endif // !DISPLAYSTATE_H