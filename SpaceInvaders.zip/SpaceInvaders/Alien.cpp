#include "Alien.h"

Alien::Alien(sf::Texture text) : Entity(text) {

}

Alien::~Alien() {

}

void Alien::display() {

}

void Alien::animation() {

}

void Alien::eraseAlien() {

}

void Alien::spawnBomb() {

}

void Alien::move() {

}