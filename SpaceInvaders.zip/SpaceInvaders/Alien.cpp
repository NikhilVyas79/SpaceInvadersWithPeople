#include "Alien.h"

Alien::Alien()
{
}

Alien::Alien(sf::Texture* text, int type) : Entity(*text) {
	sprite = new sf::Sprite(*text, sf::IntRect(5, 58, 62, 98));
}

Alien::~Alien() {
	delete sprite;
}

void Alien::draw(sf::RenderWindow* target)
{
	target->draw(*sprite);
}



void Alien::animation() {

}

void Alien::eraseAlien() {

}

void Alien::spawnBomb() {

}

void Alien::move() {

}