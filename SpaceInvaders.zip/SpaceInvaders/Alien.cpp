#include "Alien.h"

Alien::Alien()
{
}

Alien::Alien(sf::Texture* text, int type) : Entity(*text) {
	starting = sf::IntRect(5, 58, 67, 40);
	animationRect = sf::IntRect(5, 6, 67, 40);
	sprite = new sf::Sprite(*text, starting);
	sprite->setScale(sf::Vector2f(.6, .6));
	alive = true;
}

Alien::~Alien() {
	delete sprite;
}

void Alien::draw(sf::RenderWindow* target)
{
	if(alive)
		target->draw(*sprite);
	
}



void Alien::animation() 
{
	if (sprite->getTextureRect() == starting)
		sprite->setTextureRect(animationRect);
	else
		sprite->setTextureRect(starting);
}

void Alien::eraseAlien() 
{
	bool dead = false; //for the satisfation of Conn0r 
	alive = dead;
}

void Alien::spawnBomb()
{

}

void Alien::move() 
{
	sprite->move(sf::Vector2f(10*direction, 0));
	animation();
	if (direction == 1 && sprite->getPosition().x > 600 - sprite->getGlobalBounds().width)
	{
		direction = -1;
	}
	else if (direction == -1 && sprite->getPosition().x < 0)
	{
		direction = 1;
	}
}