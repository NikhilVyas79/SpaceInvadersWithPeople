#include "Alien.h"

Alien::Alien()
{
}

Alien::Alien(sf::Texture* text, int type, sf::Vector2f pos) : Entity(*text) {

	switch (type)
	{
	case 2:
		starting = sf::IntRect(0, 0, 16,16);
		animationRect = sf::IntRect(0, 16, 16, 16);
		break;
	case 3:
		starting = sf::IntRect(16, 0, 16, 16);
		animationRect = sf::IntRect(16, 16, 16, 16);
		break;
	default:
		starting = sf::IntRect(32, 0, 16, 16);
		animationRect = sf::IntRect(32, 16, 16, 16);
		break;
	}
	sprite = new sf::Sprite(*text, starting);
	sprite->setScale(sf::Vector2f(2.5, 2.5));
	alive = true;
	sprite->setPosition(pos);
}

Alien::~Alien() {
	delete sprite;
}

void Alien::draw(sf::RenderWindow* target)
{
	if(alive)
		target->draw(*sprite);
	
}



void Alien::animation() 
{
	if (sprite->getTextureRect() == starting)
		sprite->setTextureRect(animationRect);
	else
		sprite->setTextureRect(starting);
}

void Alien::eraseAlien() 
{
	bool dead = false; //for the satisfation of Conn0r 
	alive = dead;
}

void Alien::spawnBomb()
{

}

void Alien::move(int vecPosX) 
{
	animation();
	if (sprite->getPosition().x == 600 - 40 * (11 - vecPosX) || sprite->getPosition().x == 40 * vecPosX)
	{
		sprite->setPosition(sprite->getPosition().x + 1, sprite->getPosition().y + 40);
	}
	else
	{
		sprite->move(sf::Vector2f(10 * direction, 0));
		if (direction == 1 && sprite->getPosition().x > 600 - sprite->getGlobalBounds().width - (40 * (10 - vecPosX)))
		{
			sprite->setPosition(600 - 40 * (11 - vecPosX), sprite->getPosition().y);
			direction = -1;
		}
		else if (direction == -1 && sprite->getPosition().x < 5 + 40 * vecPosX)
		{
			sprite->setPosition(40 * vecPosX, sprite->getPosition().y);
			direction = 1;
		}
	}
}