#include "GameState.h"

GameState::GameState(sf::Texture* t)
{
	this->setTexture(t);
	player = new LaserCannon(t);
	setName("game");
}

GameState::~GameState()
{
}

void GameState::eventHandle(sf::Event* e)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
		player->move(true);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
		player->move(false);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
		canLas.push_back(new Laser(spriteSheet, player->getCannonPosition()));
	}
}

void GameState::keyHandle()
{
}

void GameState::draw(sf::RenderWindow* target)
{
	player->draw(target);
}

void GameState::update()
{
}

void GameState::fixedUpdate(sf::Clock clock)
{
}

int GameState::nextState(std::vector<DisplayState*>* d)
{
	return -1;
}
