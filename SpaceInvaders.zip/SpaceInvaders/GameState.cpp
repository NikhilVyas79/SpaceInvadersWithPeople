#include "GameState.h"

GameState::GameState(sf::Texture* t)
{
	this->setTexture(t);
	player = new LaserCannon(t);
	setName("game");
	las = new Laser(t);
	alien = new Alien(t, 1);
}

GameState::~GameState()
{
	delete player;
	delete las;
}

void GameState::eventHandle(sf::Event* e)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
		player->move(true);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
		player->move(false);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
		las->setLasPosition(player->getCannonPosition());
	}
}

void GameState::keyHandle()
{
}

void GameState::draw(sf::RenderWindow* target)
{
	player->draw(target);
	las->draw(target);
	alien->draw(target);
}

void GameState::update()
{
	las->move();

}

void GameState::fixedUpdate(int *frames)
{
	//std::cout << clock.getElapsedTime().asMilliseconds() << std::endl;
	if (*frames == 900)
	{
	
		alien->move();
		*frames = 0;
	}
	*frames += 1;
}

int GameState::nextState(std::vector<DisplayState*>* d)
{
	return -1;
}

