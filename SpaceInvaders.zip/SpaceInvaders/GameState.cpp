#include "GameState.h"

GameState::GameState(sf::Texture* t)
{
	this->setTexture(t);
	player = new LaserCannon(t);
	setName("game");
	las = new Laser(t);
	for (int i = 0; i < 11; i++)
	{
		aliens.push_back(std::vector<Alien*>());

		aliens.at(i).push_back(new  Alien(t, 1, sf::Vector2f(40 * i, 0)));
		aliens.at(i).push_back(new  Alien(t, 2, sf::Vector2f(40 * i, 40)));
		aliens.at(i).push_back(new  Alien(t, 2, sf::Vector2f(40 * i, 80)));
		aliens.at(i).push_back(new  Alien(t, 3, sf::Vector2f(40 * i, 120)));
		aliens.at(i).push_back(new  Alien(t, 3, sf::Vector2f(40 * i, 160)));
	}
}

GameState::~GameState()
{
	delete player;
	delete las;
}

void GameState::eventHandle(sf::Event* e)
{

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
		las->setLasPosition(player->getCannonPosition());
	}
}

void GameState::keyHandle()
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
		player->move(true);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
		player->move(false);
	}
}

void GameState::draw(sf::RenderWindow* target)
{
	player->draw(target);
	las->draw(target);

	for (int i = 0; i < aliens.size(); i++)
	{
		for (int j = 0; j < aliens.at(i).size(); j++)
		{
			aliens.at(i).at(j)->draw(target);
		}
	}
}

void GameState::update()
{
	las->move();

}

void GameState::fixedUpdate(int *frames)
{
	//std::cout << clock.getElapsedTime().asMilliseconds() << std::endl;
	if (*frames == 900)
	{
		for (int i = 0; i < aliens.size(); i++)
		{
			for (int j = 0; j < aliens.at(i).size(); j++)
			{
				aliens.at(i).at(j)->move(i);
			}
		}
	
		*frames = 0;

	}
	*frames += 1;
}

int GameState::nextState(std::vector<DisplayState*>* d)
{
	return -1;
}

