/*
Space Invaders project




contributors: Ethan Doll, Conn0r May
*/

#include <iostream>
#include <SFML/Graphics.hpp>
#include "Manager.h"

int main()
{
	StateManager control(sf::Vector2f(600, 700), "Space Invaders");
	control.init(new StartMenu());
	return 0;
}
