/*
Space Invaders project




contributors: Ethan Doll, Conn0r May
*/

#include <iostream>
#include <SFML/Graphics.hpp>

#include "Manager.h"

int main()
{
	sf::Texture spriteSheet;
	spriteSheet.loadFromFile("SpriteSheet.jpg");

	StateManager control(sf::Vector2f(600, 700), "Space Invaders");
	control.addState(new StartMenu(&spriteSheet));
	control.init(new GameState(&spriteSheet), &spriteSheet);
	return 0;
}
