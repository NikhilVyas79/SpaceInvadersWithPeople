/*
Space Invaders project




contributors: Ethan Doll, Conn0r May
*/

#include <iostream>
#include <SFML/Graphics.hpp>

#include "Manager.h"

int main()
{
	sf::Texture spriteSheet;
	spriteSheet.loadFromFile("Assets/Sprites/Menu.png");
	StartMenu* temp = new StartMenu(&spriteSheet);
	temp->setName("crack");
	StateManager control(sf::Vector2f(600, 700), "Space Invaders");
	control.addState(temp);
	control.init(new StartMenu(&spriteSheet), &spriteSheet);
	return 0;
}
