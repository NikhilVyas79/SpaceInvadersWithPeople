#include "LaserCannon.h"


LaserCannon::LaserCannon(sf::Texture * text) : Entity(*text) {
	t.setTexture(*text);
	t.setTextureRect(sf::IntRect(0, 32, 16, 16));
	t.setPosition(50, 600);
	t.setScale(4, 4);
}

LaserCannon::~LaserCannon() {

}

void LaserCannon::move(bool direc) {
	if (direc) {
		t.move(-.8, 0);
	}
	else {
		t.move(.8, 0);
	}
}

void LaserCannon::draw(sf::RenderWindow* target)
{
	target->draw(t);
}

void LaserCannon::display(sf::RenderWindow & window) {
	window.draw(t);
}

sf::Vector2f LaserCannon::getCannonPosition() {
	return sf::Vector2f(t.getPosition().x + (t.getGlobalBounds().width / 8),t.getPosition().y);
	
}
