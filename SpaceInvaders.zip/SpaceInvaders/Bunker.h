#pragma once

#include "Object.h"

class Bunker : public Object
{
public:
	Bunker();
	~Bunker();
	bool collision(sf::Vector2f);
	void display(sf::RenderWindow&);
	bool getExplosion();
	void setExplosion(bool);
	void explosion(sf::Vector2f);
private:
	int team = 0;
	int collisions = 0;
	bool explos = false;
	std::vector<sf::Vertex> vertices;
	std::vector<sf::Vertex> explosions;
};

