#pragma once

#include "Object.h"

class Bunker : public Object
{
public:
	Bunker();
	~Bunker();
	void eraseBasedOnHit(Object);
	void display(sf::RenderWindow&);

private:
	int team = 0;
	std::vector<sf::Vertex> vertices;
};

