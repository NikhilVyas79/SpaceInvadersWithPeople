#include "MysteryAlien.h"


MysteryAlien::MysteryAlien(sf::Texture text){

}

MysteryAlien::~MysteryAlien() {

}

void MysteryAlien::display() {

}

void MysteryAlien::animation() {

}

void MysteryAlien::eraseAlien() {

}