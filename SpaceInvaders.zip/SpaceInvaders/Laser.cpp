#include "Laser.h"


Laser::Laser() : Entity()
{

	
}

Laser::Laser(sf::Texture* text) : Entity(*text) {
	las.setTexture(*text);
	las.setTextureRect(sf::IntRect(25, 125, 5, 30));
	alive = false;
}

Laser::~Laser() {

}

bool Laser::checkForCollision() {
	return true;
}

void Laser::display(sf::RenderWindow & window) {
	window.draw(las);
}

void Laser::draw(sf::RenderWindow* target)
{
	if (alive)
	{
		target->draw(las);
	}
}

void Laser::move() {
	if (alive)
	{
		las.move(0, -0.3);
		alive = offScreen();
	}
}


bool Laser::offScreen() 
{
	if (las.getPosition().y < 0) {
		return false;
	}
	return true;
}

void Laser::setLasPosition(sf::Vector2f x)
{
	if (!alive)
	{
		las.setPosition(x.x + 32, x.y - 15);
		alive = true;
	}
} 