#include "Laser.h"


Laser::Laser() : Entity()
{

	
}

Laser::Laser(sf::Texture *text) :  Entity(*text){
	las.setSize(sf::Vector2f(1.5, 15.f));
	las.setPosition(1000.f, 1000.f);
	las.setFillColor(sf::Color::Green);
}

Laser::~Laser() {

}

bool Laser::checkForCollision() {
	return true;
}

void Laser::display(sf::RenderWindow & window) {
	if (las.getPosition().y > 450){
		las.setFillColor(sf::Color::Green);
	}
	else if(las.getPosition().y>100){
		las.setFillColor(sf::Color::White);
	}
	else{
		las.setFillColor(sf::Color::Red);
	}
		window.draw(las);
}

void Laser::move() {
	las.move(0, -0.4);
}

bool Laser::offScreen() {
	if (las.getPosition().y < 0) {
		return true;
	}
	return false;
}

void Laser::setLasPosition(sf::Vector2f x) {
	las.setPosition(x);
	las.move(27, -15);
}

sf::Vector2f Laser::getLasPosition() {
	return las.getPosition();
}
