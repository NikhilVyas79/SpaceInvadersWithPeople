#pragma once
#include "DisplayState.h"
#include "Laser.h"
#include "LaserCannon.h"
#include "Alien.h"
class GameState :
	public DisplayState
{
public:
	GameState(sf::Texture *t);
	~GameState();

	void virtual eventHandle(sf::Event* e) override;
	void virtual keyHandle() override;
	void virtual draw(sf::RenderWindow* target) override;
	void virtual update() override;
	void virtual fixedUpdate(sf::Clock clock) override;
	int virtual nextState(std::vector<DisplayState*>* d) override;


private:
	Laser* las;
	LaserCannon* player;
	Alien* alien;
};

