#pragma once

#include "Entity.h"

class Laser : public Entity
{
public:
	Laser();
	Laser(sf::Texture*);
	~Laser();
	bool checkForCollision();
	void display(sf::RenderWindow &);
	void draw(sf::RenderWindow*) override;
	void move();
	bool offScreen();
	void setLasPosition(sf::Vector2f);

private:
	bool alive;
	int team;
	sf::Sprite las;
};

