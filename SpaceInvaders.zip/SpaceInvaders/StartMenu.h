#pragma once
#include "DisplayState.h"

class StartMenu : public DisplayState
{
public:
	StartMenu();
	~StartMenu();


	void virtual draw(sf::RenderWindow* target) override;

private:
	sf::Sprite tempMenu;
	sf::Texture spriteSheet;
};

