#include "Bunker.h"

Bunker::Bunker(sf::Texture text) : Object(text){

}

Bunker::~Bunker() {

}

void Bunker::eraseBasedOnHit() {

}

void Bunker::display() {

}