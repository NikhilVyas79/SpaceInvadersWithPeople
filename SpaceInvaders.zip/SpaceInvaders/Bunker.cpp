#include "Bunker.h"

Bunker::Bunker(){
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 20; i++) {
			for (int g = 0; g < 18; g++) {
				if ((i + g < 5) || (i - g > 14) ||
					(i + g > 20 && g > 13 && i < 10) || (i - g <= -3 && g > 13 && i > 8)) {
				}
				else {
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 550.f+ 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 553.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 553.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 550.f + 3 * g), sf::Color::Green));
				}
			}
		}
	}
}

Bunker::~Bunker() {

}

void Bunker::eraseBasedOnHit(Object las) {
	
}

void Bunker::display(sf::RenderWindow& window) {
	window.draw(&vertices[0], vertices.size(), sf::Quads);
}