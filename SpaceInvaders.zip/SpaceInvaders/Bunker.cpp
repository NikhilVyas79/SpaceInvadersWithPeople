#include "Bunker.h"

Bunker::Bunker() {
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 20; i++) {
			for (int g = 0; g < 18; g++) {
				if ((i + g < 5) || (i - g > 14) ||
					(i + g > 20 && g > 13 && i < 10) || (i - g <= -3 && g > 13 && i > 8)) {
				}
				else {
					//Thinking that instead of using vertex arrays we just use a bunch of rectanges
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 500.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(40.f + 150 * j + 3 * i, 503.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 503.f + 3 * g), sf::Color::Green));
					vertices.push_back(sf::Vertex(sf::Vector2f(43.f + 150 * j + 3 * i, 500.f + 3 * g), sf::Color::Green));
				}
			}
		}
	}

	for (int i = 0; i < 7; i++) {
		for (int g = 0; g < 7; g++) {
			explosions.push_back(sf::Vertex(sf::Vector2f(0.f + 3 * i, 3 * g), sf::Color::Black));
			explosions.push_back(sf::Vertex(sf::Vector2f(0.f + 3 * i, 3 + 3 * g), sf::Color::Black));
			explosions.push_back(sf::Vertex(sf::Vector2f(3.f + 3 * i, 3 + 3 * g), sf::Color::Black));
			explosions.push_back(sf::Vertex(sf::Vector2f(3.f + 3 * i, 3 * g), sf::Color::Black));
		}
	}

	bool checker=false;
	int absx, absy;

	for (int i = 0; i < 49; i++) {
		for (int i = 0; i < explosions.size() / 4; i++)
		{
			if ((explosions[4 * i].position.y - 10.5 < 5 && explosions[4 * i].position.y - 10.5 > -5) &&
				(explosions[4 * i].position.x - 10.5 < 5 && explosions[4 * i].position.x - 10.5 > -5)) {
				for (int g = 0; g < 4; g++) {
					explosions[4 * i + g].color = sf::Color::Green;
				}
			}
		}
		for (int i = 0; i < explosions.size() / 4; i++)
		{
			absx = (10.5 - explosions[4 * i].position.x) * (10.5 - explosions[4 * i].position.x);
			absy = (10.5 - explosions[4 * i].position.y) * (10.5 - explosions[4 * i].position.y);
			if ((absx + absy < 200)) {
				if (checker)
				{
					for (int g = 0; g < 4; g++) {
						explosions[4 * i + g].color = sf::Color::Green;
					}
					checker = false;
				}
				else
				{
					checker = true;
				}
			}
		}
	}
}

Bunker::~Bunker() {

}

bool Bunker::collision(sf::Vector2f lasPos) {
	bool checker = false;
	int absx=0;
	int absy=0;
	for (int i = 0; i < vertices.size()/4; i++) {
		/*
			if ((vertices[4*i].position.y - lasPos.y < 1 && vertices[4*i].position.y - lasPos.y > -1) && 
				(vertices[4*i].position.x - lasPos.x < 3 && vertices[4*i].position.x - lasPos.x > -3) &&
				vertices[4*i].color == sf::Color::Green) {
				for (int g = 0; g < 4; g++) {
					vertices[4 * i + g].color = sf::Color::Black;
				}
				collisions++;
				if (collisions > 3){
					collisions = 0;
					return true;
				}
				explos = true;
			}
			if ((vertices[4 * i].position.y - lasPos.y < 1 && vertices[4 * i].position.y - lasPos.y > -1) &&
				(vertices[4 * i].position.x - lasPos.x < 5 && vertices[4 * i].position.x - lasPos.x > -5) &&
				vertices[4 * i].color == sf::Color::Green) {
				if (rand() % 10 == 0)
				{
					for (int g = 0; g < 4; g++) {
						vertices[4 * i + g].color = sf::Color::Black;
					}
					explos = true;
				}
			}
			if ((vertices[4 * i].position.y - lasPos.y < 1 && vertices[4 * i].position.y - lasPos.y > -10) &&
				(vertices[4 * i].position.x - lasPos.x < 10+rand()%7 && vertices[4 * i].position.x - lasPos.x > -10-rand()%7) &&
				vertices[4 * i].color == sf::Color::Green) {
				if (rand() % 35 == 0)
				{
					for (int g = 0; g < 4; g++) {
						vertices[4 * i + g].color = sf::Color::Black;
					}
					explos = true;
				}
			}
		*/
		if ((vertices[4 * i].position.y - lasPos.y < 1 && vertices[4 * i].position.y - lasPos.y > -1) &&
			(vertices[4 * i].position.x - lasPos.x < 2 && vertices[4 * i].position.x - lasPos.x > -2) &&
			vertices[4 * i].color == sf::Color::Green) {
			for (int g = 0; g < 4; g++) {
				vertices[4 * i + g].color = sf::Color::Black;
			}
		
			explos = true;
			for (int i = 0; i < vertices.size() / 4; i++)
			{
				if ((vertices[4 * i].position.y - lasPos.y < 5 && vertices[4 * i].position.y - lasPos.y > -5) &&
					(vertices[4 * i].position.x - lasPos.x < 5 && vertices[4 * i].position.x - lasPos.x > -5) &&
					vertices[4 * i].color == sf::Color::Green) {
					for (int g = 0; g < 4; g++) {
						vertices[4 * i + g].color = sf::Color::Black;
					}
				}
			}
			for (int i = 0; i < vertices.size() / 4; i++)
			{
				absx = (lasPos.x - vertices[4 * i].position.x)* (lasPos.x - vertices[4 * i].position.x);
				absy= (lasPos.y - vertices[4 * i].position.y) * (lasPos.y - vertices[4 * i].position.y);
				if ((absx+absy<100 && vertices[4 * i].color == sf::Color::Green)) {
					if (checker)
					{
						for (int g = 0; g < 4; g++) {
							vertices[4 * i + g].color = sf::Color::Black;
						}
						checker = false;
					}
					else
					{
						checker = true;
					}
				}
			}


			return true;
		}

	}	
	return false;
}

void Bunker::display(sf::RenderWindow& window) {
	window.draw(&vertices[0], vertices.size(), sf::Quads);
	if (explos) {
		window.draw(&explosions[0], explosions.size(), sf::Quads);
	}
}

bool Bunker::getExplosion() {
	return explos;
}

void Bunker::setExplosion(bool x) {
	explos = x;
}

void Bunker::explosion(sf::Vector2f lasPos) {
	for (int i = 0; i < 49; i++) {
		explosions.at(4 * i).position.x = lasPos.x + 3 * (i % 7) - 10;
		explosions.at(4 * i).position.y = lasPos.y + 3 * (i / 7) + 10;
		explosions.at(i*4+ 1).position.x = lasPos.x + 3 * (i % 7) - 10;
		explosions.at(i*4 + 1).position.y = lasPos.y + 3 + 3 * (i / 7) + 10;
		explosions.at(i*4 + 2).position.x = lasPos.x + 3 + (i % 7) - 10;
		explosions.at(i*4 + 2).position.y = lasPos.y + 3 + 3 * (i / 7) + 10;
		explosions.at(i*4 + 3).position.x = lasPos.x + 3 + (i % 7) - 10;
		explosions.at(i*4 + 3).position.y = lasPos.y + 3 * (i / 7) + 10;
	}
}