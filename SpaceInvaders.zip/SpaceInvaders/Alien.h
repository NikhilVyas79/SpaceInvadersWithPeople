#pragma once

#include "Entity.h"

class Alien : public Entity
{
public:
	Alien();
	Alien(sf::Texture*, int type);
	~Alien();
	virtual void draw(sf::RenderWindow* target) override;
	void animation();
	void eraseAlien();
	void spawnBomb();
	void move();

private:
	bool alive;
	int team=1;
	int direction = 1;
	sf::IntRect starting;
	sf::IntRect animationRect;
	sf::Sprite *sprite;

};

