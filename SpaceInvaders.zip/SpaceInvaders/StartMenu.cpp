#include "StartMenu.h"
#include <iostream>
StartMenu::StartMenu(sf::Texture* t)
{
	this->setTexture(t);
	player = new LaserCannon(t);
	next = false;
	setName("start");
}

StartMenu::~StartMenu()
{
	delete player;
}

void StartMenu::draw(sf::RenderWindow* target)
{
	player->draw(target);
}

void StartMenu::keyHandle()
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
		player->move(true);
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
		player->move(false);
	}



}

void StartMenu::eventHandle(sf::Event* e)
{
	if (e->type == sf::Event::KeyPressed)
	{
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::J))
			next = true;
	}
}

int StartMenu::nextState(std::vector<DisplayState*> *d)
{
	int nextboi = -1;
	if (next == true)
	{
		nextboi = findState(d, "game");
	}
	return nextboi;
}
