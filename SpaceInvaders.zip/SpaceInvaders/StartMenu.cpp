#include "StartMenu.h"

StartMenu::StartMenu()
{
	spriteSheet.loadFromFile("Assets/Sprites/Menu.png");
	tempMenu.setTexture(spriteSheet);
	tempMenu.setScale(sf::Vector2f(2, 2));
}

StartMenu::~StartMenu()
{
}

void StartMenu::draw(sf::RenderWindow* target)
{
	target->draw(tempMenu);
}
