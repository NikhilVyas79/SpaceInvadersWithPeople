#ifndef MANAGER_H
#define MANAGER_H
#include "StateManager.h"
#include "DisplayState.h"
#include "StartMenu.h"
#include "GameState.h"
#endif // !MANAGER_H

